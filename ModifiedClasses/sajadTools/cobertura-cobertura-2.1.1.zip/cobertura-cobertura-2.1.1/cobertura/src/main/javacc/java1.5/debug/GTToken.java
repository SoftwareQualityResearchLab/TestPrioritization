package net.sourceforge.cobertura.javancss.parser.java15.debug;

public class GTToken extends Token {
  int realKind = JavaParser15DebugConstants.GT;
}
