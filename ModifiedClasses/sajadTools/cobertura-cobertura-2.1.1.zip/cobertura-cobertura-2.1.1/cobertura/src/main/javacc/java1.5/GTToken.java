package net.sourceforge.cobertura.javancss.parser.java15;

public class GTToken extends Token {
  int realKind = JavaParser15Constants.GT;
}
