package test.condition;

public @interface CoverageIgnore {
}

