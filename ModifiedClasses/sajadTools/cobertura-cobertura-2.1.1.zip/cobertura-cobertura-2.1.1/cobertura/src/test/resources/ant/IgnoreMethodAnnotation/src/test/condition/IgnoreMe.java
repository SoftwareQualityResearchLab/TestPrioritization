package test.condition;

public class IgnoreMe {
  @CoverageIgnore
  public static void foo() {
    System.out.println("Ignore Me");
  }
}
