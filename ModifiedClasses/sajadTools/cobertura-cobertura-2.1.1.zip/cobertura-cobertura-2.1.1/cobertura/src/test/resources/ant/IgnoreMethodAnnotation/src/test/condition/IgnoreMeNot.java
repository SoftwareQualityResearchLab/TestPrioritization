package test.condition;


public class IgnoreMeNot {
  public static void foo() {
    System.out.println("Don't Ignore Me");
  }
}
